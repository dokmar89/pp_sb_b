"use client"

import { useState, useRef, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, RefreshCw, AlertTriangle, Upload } from "lucide-react"
import { toast } from "sonner"
import { updateShopStatus, getShopDetails } from "@/lib/actions/shops"
import { uploadLogo } from "@/lib/actions/upload"
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import type { SupabaseClient } from '@supabase/supabase-js'
import type { Database } from '@/lib/supabase/types'
import Image from "next/image"

interface ShopDetails {
  id: string
  name: string
  url: string
  status: 'active' | 'inactive'
  apiKey: string
  integration_type: 'api' | 'widget' | 'plugin'
  pricing_plan: 'contract' | 'no-contract'
  verification_methods: string[]
  logo_url?: string | null
  stats: {
    total_verifications: number
    successful_verifications: number
    failed_verifications: number
    average_time: number
  }
}

interface ShopDetailDialogProps {
  shopId: string
  open: boolean
  onOpenChange: (open: boolean) => void
}

const verificationMethodLabels = {
  'bankid': 'BankID',
  'mojeid': 'MojeID',
  'facescan': 'Skenování obličeje',
  'ocr': 'Skenování dokladů',
  'revalidate': 'Opakované ověření'
}

const integrationTypeLabels = {
  'api': 'REST API',
  'widget': 'JavaScript Widget',
  'plugin': 'Plugin pro e-shop'
}

const verificationPrices = {
  'bankid': { contract: 15, noContract: 20 },
  'mojeid': { contract: 12, noContract: 15 },
  'facescan': { contract: 4, noContract: 5 },
  'ocr': { contract: 8, noContract: 10 },
  'revalidate': { contract: 1, noContract: 2 }
}

export function ShopDetailDialog({
  shopId,
  open,
  onOpenChange
}: ShopDetailDialogProps) {
  const [shop, setShop] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (open && shopId) {
      loadShopDetails()
    }
  }, [open, shopId])

  const loadShopDetails = async () => {
    try {
      setLoading(true)
      const response = await getShopDetails(shopId)
      if (response.success) {
        setShop(response.data)
      } else {
        toast.error(response.error)
      }
    } catch (error) {
      console.error("Error loading shop details:", error)
      toast.error("Nepodařilo se načíst detaily eshopu")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Detail eshopu</DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center p-4">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        ) : shop ? (
          <div className="space-y-4">
            <div className="flex items-start gap-4">
              {shop.logo_url && (
                <Image
                  src={shop.logo_url}
                  alt="Logo eshopu"
                  width={100}
                  height={100}
                  className="rounded-lg object-contain"
                />
              )}
              <div>
                <h3 className="font-semibold">{shop.name}</h3>
                <p className="text-sm text-muted-foreground">{shop.url}</p>
              </div>
            </div>

            <div className="grid gap-4">
              <div>
                <h4 className="font-medium mb-2">Povolené metody ověření</h4>
                <div className="flex flex-wrap gap-2">
                  {shop.verification_methods?.map((method: string) => (
                    <Badge key={method} variant="secondary">
                      {method}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Statistiky</h4>
                <div className="grid grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="p-4">
                      <CardTitle className="text-xl">{shop.stats.verifications.total}</CardTitle>
                      <CardDescription>Celkem ověření</CardDescription>
                    </CardHeader>
                  </Card>
                  <Card>
                    <CardHeader className="p-4">
                      <CardTitle className="text-xl text-green-600">
                        {shop.stats.verifications.completed}
                      </CardTitle>
                      <CardDescription>Úspěšných</CardDescription>
                    </CardHeader>
                  </Card>
                  <Card>
                    <CardHeader className="p-4">
                      <CardTitle className="text-xl text-red-600">
                        {shop.stats.verifications.failed}
                      </CardTitle>
                      <CardDescription>Neúspěšných</CardDescription>
                    </CardHeader>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="p-4 text-center text-muted-foreground">
            Eshop nebyl nalezen
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
} 